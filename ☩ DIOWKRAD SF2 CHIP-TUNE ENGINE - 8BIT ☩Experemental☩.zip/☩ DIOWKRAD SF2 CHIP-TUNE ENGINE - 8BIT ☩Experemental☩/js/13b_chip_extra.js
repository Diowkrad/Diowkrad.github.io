/* ============================================================
   ФАЙЛ 13b/13: 13b_chip_extra.js
   Секция: надстройки над монолитом — бенд-слайдер, арпеджио,
   отвод анализатора, осциллограф движка, второй LCD (сводка)
   Движок не трогается: только добавленные обработчики и опрос.
   ============================================================ */
(function(){
'use strict';

/* ---------- громкость: подпись ---------- */
var volLbl=document.getElementById('volLbl');
if(volLbl){
  var updVol=function(){ volLbl.textContent=document.getElementById('vol').value; };
  document.getElementById('vol').addEventListener('input',updVol);
  updVol();
}

/* ---------- питч-бенд: монолит знает бенд из MIDI; слайдер пишет в тот же bendCents ---------- */
var bendEl=document.getElementById('bend'), bendLbl=document.getElementById('bendLbl');
if(bendEl&&bendLbl){
  bendEl.addEventListener('input',function(){
    bendCents=parseInt(bendEl.value,10)||0;
    bendLbl.textContent=bendCents+' ц';
    if(typeof applyBend==='function') applyBend();
  });
}

/* ---------- арпеджио-демо ---------- */
var arpBtn=document.getElementById('btnArp');
if(arpBtn) arpBtn.addEventListener('click',function(){
  var seq=[60,64,67,72,67,64,60,55], i=0;
  var iv=setInterval(function(){
    if(i>=seq.length){ clearInterval(iv); return; }
    var n=seq[i++];
    if(typeof chipOn==='function'){
      chipOn(n);
      setTimeout(function(){ chipOff(n); },180);
    }
  },200);
});

/* ---------- отвод анализатора: как только монолит создаст audioCtx,
   подключаемся параллельно к master (анализатор ничего не излучает) ---------- */
window.analyser=null;
(function tapLoop(){
  requestAnimationFrame(tapLoop);
  if(typeof audioCtx==='undefined'||!audioCtx||window.analyser) return;
  try{
    var an=audioCtx.createAnalyser();
    an.fftSize=2048; an.smoothingTimeConstant=0;
    master.connect(an);
    window.analyser=an;
    if(typeof log==='function') log('13b: анализатор подключён к мастер-тракту.');
  }catch(_){}
})();

/* ---------- осциллограф движка (#scope): волна с синхронизацией по фронту ---------- */
(function scopeLoop(){
  var cv=document.getElementById('scope'); if(!cv) return;
  var ctx=cv.getContext('2d');
  var buf=null, lastT=0;
  function draw(){
    requestAnimationFrame(draw);
    var ts=performance.now(); if(ts-lastT<33) return; lastT=ts;
    var an=window.analyser;
    ctx.fillStyle='#050d08'; ctx.fillRect(0,0,cv.width,cv.height);
    ctx.strokeStyle='#174a17'; ctx.lineWidth=1;
    for(var x=0;x<cv.width;x+=30){ ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,cv.height); ctx.stroke(); }
    for(var y=0;y<cv.height;y+=14){ ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(cv.width,y); ctx.stroke(); }
    ctx.strokeStyle='#2d6a2d';
    ctx.beginPath(); ctx.moveTo(0,cv.height/2); ctx.lineTo(cv.width,cv.height/2); ctx.stroke();
    if(!an) return;
    if(!buf||buf.length!==an.fftSize) buf=new Float32Array(an.fftSize);
    an.getFloatTimeDomainData(buf);
    var start=0;
    for(var i=1;i<buf.length/2;i++){ if(buf[i-1]<0&&buf[i]>=0){ start=i; break; } }
    var span=Math.floor(buf.length/2);
    ctx.strokeStyle='#9bbc0f'; ctx.lineWidth=2; ctx.beginPath();
    for(i=0;i<cv.width;i++){
      var v=buf[start+Math.floor(i*span/cv.width)]||0;
      var yy=cv.height/2+v*cv.height*0.45;
      if(i===0) ctx.moveTo(i,yy); else ctx.lineTo(i,yy);
    }
    ctx.stroke(); ctx.lineWidth=1;
  }
  draw();
})();

/* ---------- второй LCD: сводка чипа (опрос, движок не трогает) ---------- */
(function lcd2Loop(){
  var el=document.getElementById('lcd2'); if(!el) return;
  var NOTE=['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'];
  function nn(n){ return NOTE[((n%12)+12)%12]+(Math.floor(n/12)-1); }
  var last='', lastT=0;
  function paint(){
    requestAnimationFrame(paint);
    var ts=performance.now(); if(ts-lastT<150) return; lastT=ts;
    if(typeof state==='undefined'||typeof chipVoiceById!=='function') return;
    var v=chipVoiceById(state.chipVoice);
    var total=(typeof activeChip!=='undefined'?activeChip.size:0)
             +(typeof activeSF2!=='undefined'?activeSF2.size:0)
             +(typeof activeMidi!=='undefined'?activeMidi.size:0);
    var lastNote='';
    if(typeof activeChip!=='undefined'&&activeChip.size>0){
      var mx=0; activeChip.forEach(function(_,k){ if(k>mx) mx=k; });
      lastNote=' НОТА:['+nn(mx)+']';
    }
    var line='ГОЛОС:['+(v?v.name:'?')+'] ОКТ: '+pcBase+
             ' БЕНД:'+(bendCents>0?'+':'')+bendCents+' ц'+
             ' ГЛАСА:'+total+lastNote;
    if(line!==last){ el.textContent=line; last=line; }
  }
  paint();
})();
})();
