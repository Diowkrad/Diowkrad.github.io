/* ============================================================
   ФАЙЛ 15/13: 15_oscilloscope.js
   Секция: независимый осциллограф (волна / спектр / фигура)
   Движок не трогает: читает только analyser (отвод 13b) и audioCtx.
   ============================================================ */
(function(){
'use strict';
var cv=document.getElementById('scope2'), ctx=cv.getContext('2d');
var lcd=document.getElementById('sc2Lcd');
if(!cv) return;
var mode='wave', frozen=false, snap=null, lastT=0;
var timeBuf=null, freqBuf=null;
var NOTE=['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'];

function setMode(m){
  mode=m; if(m!=='wave') frozen=false;
  document.querySelectorAll('#scope2Panel .wbtn').forEach(function(b,i){
    b.classList.toggle('on',['wave','spec','xy'].indexOf(mode)===i);
  });
}
document.getElementById('sc2Wave').addEventListener('click',function(){setMode('wave');});
document.getElementById('sc2Spec').addEventListener('click',function(){setMode('spec');});
document.getElementById('sc2XY').addEventListener('click',function(){setMode('xy');});
document.getElementById('sc2Freeze').addEventListener('click',function(){
  if(frozen){ frozen=false; snap=null; }
  else if(timeBuf){ snap=timeBuf.slice(); frozen=true; }
});

function grid(){
  ctx.fillStyle='#050d08'; ctx.fillRect(0,0,cv.width,cv.height);
  ctx.strokeStyle='#174a17'; ctx.lineWidth=1;
  for(var x=0;x<cv.width;x+=30){ ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,cv.height); ctx.stroke(); }
  for(var y=0;y<cv.height;y+=18){ ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(cv.width,y); ctx.stroke(); }
  ctx.strokeStyle='#2d6a2d';
  ctx.beginPath(); ctx.moveTo(0,cv.height/2); ctx.lineTo(cv.width,cv.height/2); ctx.stroke();
}

function fetch(){
  var an=window.analyser, ac=null;
  try{ ac=audioCtx; }catch(_){}
  if(!an||!ac) return null;
  if(!timeBuf||timeBuf.length!==an.fftSize){
    timeBuf=new Float32Array(an.fftSize);
    freqBuf=new Uint8Array(an.frequencyBinCount);
  }
  an.getFloatTimeDomainData(timeBuf);
  an.getByteFrequencyData(freqBuf);
  return ac;
}

function findTrigger(buf){
  for(var i=1;i<buf.length/2;i++) if(buf[i-1]<0&&buf[i]>=0) return i;
  return 0;
}

function freqOfPeak(ac){
  var top=-1,tv=0;
  for(var i=2;i<freqBuf.length-1;i++) if(freqBuf[i]>tv){ tv=freqBuf[i]; top=i; }
  if(tv<60||top<1) return null;
  var a=freqBuf[top-1],b=freqBuf[top],c=freqBuf[top+1]||0;
  var d=(a-c)/(2*(a-2*b+c))||0;
  var f=(top+d)*ac.sampleRate/2/freqBuf.length;
  var n=69+12*Math.log2(f/440);
  return f.toFixed(1)+' Гц ~ '+NOTE[((Math.round(n)%12)+12)%12]+(Math.floor(Math.round(n)/12)-1);
}

function drawWave(buf){
  grid();
  var start=findTrigger(buf);
  var span=Math.min(buf.length-start,Math.floor(buf.length/2));
  ctx.strokeStyle='#9bbc0f'; ctx.lineWidth=2; ctx.beginPath();
  for(var i=0;i<cv.width;i++){
    var v=buf[start+Math.floor(i*span/cv.width)]||0;
    var yy=cv.height/2+v*cv.height*0.45;
    if(i===0) ctx.moveTo(i,yy); else ctx.lineTo(i,yy);
  }
  ctx.stroke(); ctx.lineWidth=1;
}

var acSf=44100;
function drawSpec(){
  grid();
  if(!freqBuf) return;
  var bw=cv.width/freqBuf.length, top=0;
  ctx.fillStyle='#9bbc0f';
  for(var i=2;i<freqBuf.length;i++){
    var h=(freqBuf[i]/255)*cv.height;
    if(h>1) ctx.fillRect(i*bw,cv.height-h,bw,h);
    if(freqBuf[i]>top) top=freqBuf[i];
  }
  ctx.strokeStyle='#2d6a2d';
  for(var f=1000;f<acSf/2;f+=1000){
    var xx=f/(acSf/2)*cv.width;
    ctx.beginPath(); ctx.moveTo(xx,0); ctx.lineTo(xx,cv.height); ctx.stroke();
  }
}

function drawXY(buf){
  grid();
  ctx.strokeStyle='#9bbc0f'; ctx.beginPath();
  var off=Math.floor(buf.length/4), n=Math.min(cv.width,800);
  for(var i=0;i<n;i++){
    var a=buf[Math.floor(i*buf.length/n/2)]||0;
    var b=buf[(Math.floor(i*buf.length/n/2)+off)%buf.length]||0;
    var xx=cv.width/2+a*cv.width*0.42;
    var yy=cv.height/2+b*cv.height*0.42;
    if(i===0) ctx.moveTo(xx,yy); else ctx.lineTo(xx,yy);
  }
  ctx.stroke();
}

function loop(ts){
  requestAnimationFrame(loop);
  if(frozen&&snap){ drawWave(snap); return; }
  var ac=fetch();
  if(!ac){ if(mode==='wave') grid(); return; }
  acSf=ac.sampleRate;
  if(ts-lastT<33) return; lastT=ts;
  if(mode==='wave') drawWave(timeBuf);
  else if(mode==='spec') drawSpec();
  else drawXY(timeBuf);
  var pk=freqOfPeak(ac);
  var info='OSC '+mode.toUpperCase()+(pk?' | '+pk:'');
  if(info!==loop._l){ lcd.textContent=info; loop._l=info; }
}
requestAnimationFrame(loop);
})();
