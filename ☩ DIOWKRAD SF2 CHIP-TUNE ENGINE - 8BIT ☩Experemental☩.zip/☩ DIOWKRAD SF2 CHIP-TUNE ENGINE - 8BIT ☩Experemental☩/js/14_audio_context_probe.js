/* ============================================================
   ФАЙЛ 14/13: 14_audio_context_probe.js
   Секция: независимый контроль аудио-тракта
   Движок не трогает: оборачивает прототипы Web Audio (счётчики)
   и только ЧИТАЕТ глобальные audioCtx / analyser / activeChip.
   ============================================================ */
(function(){
'use strict';
var W=window;
function G(name){ try{ return typeof eval!=='undefined'&&name in W?W[name]:null; }catch(_){ return null; } }
function GV(name){ /* чтение глобальных let/const монолита */
  try{ return eval(name); }catch(_){ return undefined; }
}
var stat={created:{},live:new Set(),bufN:0,bufBytes:0,ctxHooked:false,dcWarn:false,silentWarn:false};

/* ---------- 1. обёртки создания узлов ---------- */
function wrapCtor(Ctor,name,label){
  if(!Ctor||!Ctor.prototype||!Ctor.prototype[name]||Ctor.prototype[name].__ad) return;
  var orig=Ctor.prototype[name];
  Ctor.prototype[name]=function(){
    var n=orig.apply(this,arguments);
    if(n){
      stat.created[label]=(stat.created[label]||0)+1;
      if(typeof n.start==='function'){
        stat.live.add(n);
        if(typeof n.addEventListener==='function')
          n.addEventListener('ended',function(){ stat.live.delete(n); });
      }
    }
    return n;
  };
  Ctor.prototype[name].__ad=true;
}
[
  ['createBufferSource','BufferSource'],['createOscillator','Oscillator'],
  ['createGain','Gain'],['createBiquadFilter','BiquadFilter'],
  ['createWaveShaper','WaveShaper'],['createDynamicsCompressor','Compressor'],
  ['createDelay','Delay'],['createStereoPanner','StereoPanner']
].forEach(function(p){ wrapCtor(W.AudioContext,p[0],p[1]); wrapCtor(W.webkitAudioContext,p[0],p[1]); });
[W.AudioContext,W.webkitAudioContext].forEach(function(C){
  if(!C||!C.prototype||!C.prototype.createBuffer||C.prototype.createBuffer.__ad) return;
  var orig=C.prototype.createBuffer;
  C.prototype.createBuffer=function(ch,len,sr){
    var b=orig.apply(this,arguments);
    stat.bufN++; stat.bufBytes+=ch*len*4;
    return b;
  };
  C.prototype.createBuffer.__ad=true;
});

/* ---------- 2. журнал модуля ---------- */
var logEl=document.getElementById('adLog');
function adLog(m){
  if(!logEl) return;
  var d=new Date(), t=('0'+d.getHours()).slice(-2)+':'+('0'+d.getMinutes()).slice(-2)+':'+('0'+d.getSeconds()).slice(-2);
  var row=document.createElement('div'); row.textContent='['+t+'] '+m;
  logEl.insertBefore(row,logEl.firstChild);
  while(logEl.children.length>8) logEl.removeChild(logEl.lastChild);
}
function db(v){ return v<=0.00001?'-inf':(20*Math.log10(v)).toFixed(1); }

/* ---------- 3. стоп-тест ---------- */
document.getElementById('adFreeze').addEventListener('click',function(){
  var ac=GV('audioCtx'); if(!ac){ adLog('контекст ещё не создан'); return; }
  ac.suspend().then(function(){ adLog('КОНТЕКСТ ПРИОСТАНОВЛЕН'); });
});
document.getElementById('adResume').addEventListener('click',function(){
  var ac=GV('audioCtx'); if(!ac) return;
  ac.resume().then(function(){ adLog('контекст возобновлён'); });
});

/* ---------- 4. цикл опроса ---------- */
var lcd=document.getElementById('adLcd'), last='', lastT=0;
var timeBuf=null, freqBuf=null, NOTE=['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'];
function put(s){ if(s!==last&&lcd){ lcd.textContent=s; last=s; } }
function loop(ts){
  requestAnimationFrame(loop);
  if(ts-lastT<200) return; lastT=ts;
  var ac=GV('audioCtx');
  if(!ac){ put('AUDIO: контекст ещё не создан'); return; }
  if(!stat.ctxHooked){
    stat.ctxHooked=true;
    adLog('контекст: '+ac.sampleRate+' Гц, латентность '+((ac.baseLatency||0)*1000).toFixed(1)+' мс');
    ac.addEventListener('statechange',function(){ adLog('состояние контекста: '+ac.state); });
  }
  var line='AUDIO '+ac.state.toUpperCase()+' '+(Math.round(ac.sampleRate/100)/10)+'кГц';
  var an=W.analyser;
  if(an){
    if(!timeBuf||timeBuf.length!==an.fftSize){ timeBuf=new Float32Array(an.fftSize); freqBuf=new Uint8Array(an.frequencyBinCount); }
    an.getFloatTimeDomainData(timeBuf);
    an.getByteFrequencyData(freqBuf);
    var peak=0,sum=0,mean=0,clip=0;
    for(var i=0;i<timeBuf.length;i++){
      var x=timeBuf[i], a=x<0?-x:x;
      if(a>peak) peak=a;
      if(a>=0.999) clip++;
      sum+=x*x; mean+=x;
    }
    mean/=timeBuf.length;
    var rms=Math.sqrt(sum/timeBuf.length);
    var dc=Math.abs(mean)*100;
    var top=-1,tv=0;
    for(i=0;i<freqBuf.length;i++) if(freqBuf[i]>tv){ tv=freqBuf[i]; top=i; }
    line+=' | пик '+db(peak)+'дБ RMS '+db(rms)+'дБ | DC '+dc.toFixed(1)+'%'+
          ' | клип '+clip+' | пик спектра '+(tv>60?Math.round(top*ac.sampleRate/2/freqBuf.length)+' Гц':'-');
    var aC=GV('activeChip')||new Map(), aS=GV('activeSF2')||new Map(), aM=GV('activeMidi')||new Map();
    var silent=!(aC.size||aS.size||aM.size);
    if(silent&&rms>0.004&&!stat.silentWarn){ stat.silentWarn=true; adLog('ФОН при тишине: RMS '+db(rms)+' дБ — источник в тракте'); }
    if(!silent) stat.silentWarn=false;
    if(dc>1.5&&!stat.dcWarn){ stat.dcWarn=true; adLog('DC-смещение '+dc.toFixed(1)+'% — буфер без нормализации среднего'); }
    if(dc<0.5) stat.dcWarn=false;
  }
  var L=[];
  for(var k in stat.created) L.push(k.split('')[0]+' '+stat.created[k]);
  line+=' | созд:'+(L.join(' ')||'0');
  var liveCnt={};
  stat.live.forEach(function(n){ liveCnt[n.__adLabel||'?']=(liveCnt[n.__adLabel||'?']||0)+1; });
  var LL=[]; for(k in liveCnt) LL.push(k.split('')[0]+' '+liveCnt[k]);
  line+=' | жив:'+(LL.join(' ')||'0');
  line+=' | буф: '+stat.bufN+' ('+(stat.bufBytes/1024).toFixed(0)+' КБ)';
  put(line);
}
requestAnimationFrame(loop);
})();
