/* ================================================================
   🧸 DIOWKRAD FRAMEWORK v0.1 «Конвейер в коробке»
   Фреймворк-каркас на основе DIOWKRAD SF2 CHIP-TUNE ENGINE v1.6.6
   Все степени защиты — в вызываемые функции, которыми можно
   обернуть любой звук.
   ----------------------------------------------------------------
   ПРИНЦИП (как в движке):
     - fail-soft: эффект упал — звук идёт дальше, поломка в журнал;
     - гард на каждом параметре: кривое значение -> безопасное ещё
       ДО звука;
     - читаемость важнее компактности: комментарии для наследников.
   ----------------------------------------------------------------
   ИСТОЧНИК ДЕФОЛТОВ: пульт движка v1.6.6.
   Если константа расходится с внутренностями движка — помечена
   тегом [СВЕРИТЬ]. Сверить при первом подключении к живому файлу.
   ================================================================ */
'use strict';

const DWK = (() => {

  /* ==============================================================
     РАЗДЕЛ 1. ЖУРНАЛ (fail-soft, стиль челлендж-лога)
     Каждая запись: версия | стадия | что случилось | что сделали.
     Это готовый материал для брошюрки «Поломка и решение».
     ============================================================== */
  const Log = {
    entries: [],
    push(stage, msg, fix) {
      this.entries.push({
        t: Date.now(),
        ver: DWK.VERSION,
        stage,
        msg: String(msg),
        fix: fix || 'звук пропущен без изменений (fail-soft)'
      });
      if (this.entries.length > 500) this.entries.shift(); // не пухнем бесконечно
      if (typeof console !== 'undefined' && console.warn) {
        console.warn(`[DWK ${stage}] ${msg} — ${fix || 'fail-soft'}`);
      }
    },
    dump() { return this.entries.slice(); },
    clear() { this.entries.length = 0; }
  };

  /* ==============================================================
     РАЗДЕЛ 2. ГАРДЫ — вызываемые функции защиты.
     Каждая: (значение, ...) -> безопасное значение.
     Ни одна не бросает исключений: только чинит и пишет в журнал.
     ============================================================== */
  const Guards = {
    /* число: не число -> дефолт, вне диапазона -> прижать к границе */
    num(v, min, max, def, name) {
      if (typeof v !== 'number' || !isFinite(v)) {
        Log.push('GARD.num', `${name}: не число (${v})`, `взят дефолт ${def}`);
        return def;
      }
      if (v < min) { Log.push('GARD.num', `${name}: ${v} < ${min}`, 'прижато к границе'); return min; }
      if (v > max) { Log.push('GARD.num', `${name}: ${v} > ${max}`, 'прижато к границе'); return max; }
      return v;
    },
    /* целое в диапазоне (биты крашера, октавы и т.п.) */
    int(v, min, max, def, name) {
      return Math.round(Guards.num(v, min, max, def, name));
    },
    /* значение из списка допустимых */
    oneOf(v, list, def, name) {
      if (list.includes(v)) return v;
      Log.push('GARD.oneOf', `${name}: недопустимое значение (${v})`, `взят дефолт ${def}`);
      return def;
    },
    /* буфер: чистит NaN/Infinity, прижимает клиппинг [-1;1].
       Работает на месте и возвращает тот же массив. */
    buffer(data) {
      if (!(data instanceof Float32Array)) {
        Log.push('GARD.buffer', 'вход не Float32Array', 'выход как есть');
        return data;
      }
      for (let i = 0; i < data.length; i++) {
        const x = data[i];
        if (!isFinite(x)) { data[i] = 0; }
        else if (x > 1)   data[i] = 1;
        else if (x < -1)  data[i] = -1;
      }
      return data;
    },
    /* нота в диапазоне движка 24..78 (из справки пульта).
       Вне диапазона -> null, звук не запускается (как в движке). */
    note(n) {
      const N = Guards.int(n, 0, 127, -1, 'нота');
      if (N < DWK.NOTE_MIN || N > DWK.NOTE_MAX) {
        Log.push('GARD.note', `нота ${n} вне диапазона ${DWK.NOTE_MIN}-${DWK.NOTE_MAX}`, 'звук не запущен');
        return null;
      }
      return N;
    },
    /* прогон целого объекта настроек через схему гард */
    shape(spec, obj) {
      const out = {};
      for (const key of Object.keys(spec)) {
        const [type, min, max, def] = spec[key];
        out[key] = type === 'int'  ? Guards.int(obj && obj[key], min, max, def, key)
                 : type === 'oneOf'? Guards.oneOf(obj && obj[key], min, max, key)
                 : Guards.num(obj && obj[key], min, max, def, key);
      }
      return out;
    }
  };

  /* ==============================================================
     РАЗДЕЛ 3. ВОЛНЫ — генератор огибающих по кнопкам пульта:
     КВАДРАТ (4 дьюти), ТРЕУГОЛЬНИК + БАС, ПИЛА + БАС,
     СИНУС + БАС, КРУГ, N-ВОЛНА. [СВЕРИТЬ] формулы с движком.
     ============================================================== */
  const Waves = {
    /* phase в [0;1) — фаза отсчёта */
    square(phase, duty) {
      const d = Guards.num(duty, 0.0625, 0.5, 0.5, 'дьюти-цикл');
      return (phase % 1) < d ? 1 : -1;
    },
    triangle(phase) {
      const p = ((phase % 1) + 1) % 1;
      return p < 0.5 ? (4 * p - 1) : (3 - 4 * p);
    },
    saw(phase) {
      const p = ((phase % 1) + 1) % 1;
      return 2 * p - 1;
    },
    sine(phase) {
      return Math.sin(2 * Math.PI * phase);
    },
    /* «КРУГ»: [СВЕРИТЬ] реализация из движка; здесь — синус со
       сдвигом фазы (косинус), как дешёвая «круглая» волна. */
    circle(phase) {
      return Math.cos(2 * Math.PI * phase);
    },
    /* «N-ВОЛНА»: [СВЕРИТЬ] форма из движка; здесь — гибрид
       треугольник-пила (N-образный профиль). */
    nwave(phase) {
      const p = ((phase % 1) + 1) % 1;
      return p < 0.25 ? 4 * p : (p < 0.75 ? 2 - 4 * p : 4 * p - 4);
    },
    /* завод по имени кнопки пульта */
    factory(name) {
      const dutyMap = {
        'square':        { fn: (ph) => Waves.square(ph, 0.5),    duty: 0.5    },
        'square50':      { fn: (ph) => Waves.square(ph, 0.5),    duty: 0.5    },
        'square25':      { fn: (ph) => Waves.square(ph, 0.25),   duty: 0.25   },
        'square12.5':    { fn: (ph) => Waves.square(ph, 0.125),  duty: 0.125  },
        'square6.25':    { fn: (ph) => Waves.square(ph, 0.0625), duty: 0.0625 },
        'triangle':      { fn: (ph) => Waves.triangle(ph) },
        'triangleBass':  { fn: (ph) => Waves.triangle(ph) },   /* [СВЕРИТЬ] окраска баса в движке */
        'saw':           { fn: (ph) => Waves.saw(ph) },
        'sawBass':       { fn: (ph) => Waves.saw(ph) },        /* [СВЕРИТЬ] */
        'sine':          { fn: (ph) => Waves.sine(ph) },
        'sineBass':      { fn: (ph) => Waves.sine(ph) },       /* [СВЕРИТЬ] */
        'circle':        { fn: (ph) => Waves.circle(ph) },
        'nwave':         { fn: (ph) => Waves.nwave(ph) }
      };
      return dutyMap[Guards.oneOf(name, Object.keys(dutyMap), 'square', 'волна')].fn;
    },
    /* наполнить буфер: частота, длина, стартовая фаза -> {data, phase} */
    fill(name, freq, len, sampleRate, phase0) {
      const fn = Waves.factory(name);
      const data = new Float32Array(Guards.int(len, 1, 1e8, 1, 'длина буфера'));
      let phase = ((phase0 || 0) % 1 + 1) % 1;
      const inc = Math.max(0, freq) / Math.max(1, sampleRate);
      for (let i = 0; i < len; i++) { data[i] = fn(phase); phase += inc; phase %= 1; }
      return { data, phase };
    }
  };

  /* ==============================================================
     РАЗДЕЛ 4. ЭФФЕКТЫ — 8 из МИКШЕРА движка.
     Порядок в конвейере (см. Processor): как на пульте от входа
     к выходу. [СВЕРИТЬ] реальный порядок цепочки в движке.
     ============================================================== */
  const DEFAULTS = {
    delay:    { time: 250, feedback: 0.30, mix: 0 },     /* ВРЕМЯ:250мс, ОС:30%, МИКС:0% */
    reverb:   { mix: 0 },                                /* РЕВЕРБ МИКС:0% */
    dist:     { grain: 20, mix: 0, volume: 0.05 },       /* ГРЕЙН:20, МИКС:0%, ГРОМК:5% */
    double:   { time: 25, mix: 0 },                      /* ДТ ЗАДЕРЖКА:25мс, ДТ МИКС:0% */
    vibrato:  { rate: 5.0, depth: 1.5, mix: 0 },         /* СКОРОСТЬ:5.0Гц, ГЛУБИНА:1.5мс */
    phaser:   { rate: 0.6, depth: 600, mix: 0 },         /* СКОРОСТЬ:0.6Гц, ГЛУБИНА:600Гц */
    gate:     { threshold: -40 },                        /* ГЕЙТ ПОРОГ:-40дБ */
    crusher:  { bits: 8, rate: 48000 }                   /* ГЛУБИНА:8 БИТ, ЧАСТОТА:48кГц */
  };

  /* фабрика одного эффекта: state держится внутри, конвейер не знает деталей */
  function makeEffect(name) {
    const D = DEFAULTS[name];
    const st = {};

    const SPEC = {
      delay:    { time:    ['int',  10,   2000, D.time],
                  feedback:['num',  0,    0.95, D.feedback], /* потолок 0.95: эхо не захлёбывается */
                  mix:     ['num',  0,    1,    D.mix] },
      reverb:   { mix:     ['num',  0,    1,    D.mix] },
      dist:     { grain:   ['int',  1,    100,  D.grain],
                  mix:     ['num',  0,    1,    D.mix],
                  volume:  ['num',  0,    1,    D.volume] },
      double:   { time:    ['int',  1,    200,  D.time],
                  mix:     ['num',  0,    1,    D.mix] },
      vibrato:  { rate:    ['num',  0.1,  20,   D.rate],
                  depth:   ['num',  0,    20,   D.depth],
                  mix:     ['num',  0,    1,    D.mix] },
      phaser:   { rate:    ['num',  0.05, 10,   D.rate],
                  depth:   ['int',  10,   3000, D.depth],
                  mix:     ['num',  0,    1,    D.mix] },
      gate:     { threshold:['num', -80,   0,   D.threshold] },
      crusher:  { bits:    ['int',  2,    16,   D.bits],
                  rate:    ['int',  2000, 192000, D.rate] }
    };

    const fx = {
      name,
      on: false, /* тумблеры пульта стартуют ВЫКЛ */
      set(patch) {
        fx.params = Guards.shape(SPEC, Object.assign({}, D, patch || {}));
        return fx;
      },
      params: Guards.shape(SPEC, D),

      /* основная работа. Возвращает обработанный буфер. */
      process(data, sr) {
        if (!fx.on) return data; /* тумблер ВЫКЛ — прозрачный проход */
        try {
          return fx.impl(data, sr);
        } catch (e) {
          Log.push('FX.' + name, e && e.message ? e.message : String(e));
          return data; /* fail-soft: звук идёт дальше */
        }
      },

      /* ---- реализации [СВЕРИТЬ] с нативными стадиями движка ---- */
      impl(data, sr) {
        const P = fx.params, N = data.length;

        switch (name) {

        case 'delay': {
          const dly = Math.max(1, Math.round(sr * P.time / 1000));
          if (!st.buf || st.buf.length !== dly) st.buf = new Float32Array(dly), st.pos = 0;
          const out = new Float32Array(N);
          for (let i = 0; i < N; i++) {
            const echo = st.buf[st.pos];
            out[i] = data[i] + echo * P.mix;
            st.buf[st.pos] = data[i] + echo * P.feedback; /* потолок 0.95 в гарде */
            st.pos = (st.pos + 1) % dly;
          }
          return Guards.buffer(out);
        }

        case 'reverb': {
          /* простая гребёнка+аллпасс, [СВЕРИТЬ] настоящий реверб движка */
          if (!st.b1) st.b1 = new Float32Array(Math.round(sr * 0.037)),
                     st.b2 = new Float32Array(Math.round(sr * 0.011)),
                     st.p1 = 0, st.p2 = 0;
          const out = new Float32Array(N);
          for (let i = 0; i < N; i++) {
            const wet = st.b1[st.p1] * 0.6 + st.b2[st.p2] * 0.6;
            out[i] = data[i] + wet * P.mix;
            st.b1[st.p1] = data[i] + st.b1[st.p1] * 0.6;
            st.b2[st.p2] = data[i] + st.b2[st.p2] * 0.6;
            st.p1 = (st.p1 + 1) % st.b1.length;
            st.p2 = (st.p2 + 1) % st.b2.length;
          }
          return Guards.buffer(out);
        }

        case 'dist': {
          const k = Math.max(1, P.grain) / 20; /* ГРЕЙН:20 — середина шкалы -> мягкий сат */
          const out = new Float32Array(N);
          for (let i = 0; i < N; i++) {
            const x = Math.tanh(k * data[i]) / Math.tanh(k);
            out[i] = (data[i] * (1 - P.mix) + x * P.mix) * P.volume;
          }
          return Guards.buffer(out);
        }

        case 'double': {
          const dly = Math.max(1, Math.round(sr * P.time / 1000));
          if (!st.buf || st.buf.length !== dly) st.buf = new Float32Array(dly), st.pos = 0;
          const out = new Float32Array(N);
          for (let i = 0; i < N; i++) {
            out[i] = (data[i] + st.buf[st.pos] * P.mix) / (1 + P.mix * 0.5);
            st.buf[st.pos] = data[i];
            st.pos = (st.pos + 1) % dly;
          }
          return Guards.buffer(out);
        }

        case 'vibrato': {
          /* глубина в мс -> задержка с модуляцией, [СВЕРИТЬ] */
          if (!st.buf) st.buf = new Float32Array(Math.round(sr * 0.02)), st.pos = 0;
          const out = new Float32Array(N);
          let ph = st.ph || 0;
          for (let i = 0; i < N; i++) {
            const dep = Math.sin(2 * Math.PI * ph) * P.depth / 1000 * sr;
            const rp = (st.pos - Math.max(0, dep) + st.buf.length) % st.buf.length;
            out[i] = data[i] * (1 - P.mix) + st.buf[Math.floor(rp)] * P.mix;
            st.buf[st.pos] = data[i];
            st.pos = (st.pos + 1) % st.buf.length;
            ph += P.rate / sr; ph %= 1;
          }
          st.ph = ph;
          return Guards.buffer(out);
        }

        case 'phaser': {
          /* однополосный аллпасс с модуляцией, [СВЕРИТЬ] */
          const out = new Float32Array(N);
          let ph = st.ph || 0, a1 = st.a1 || 0;
          let x1 = st.x1 || 0, y1 = st.y1 || 0;
          for (let i = 0; i < N; i++) {
            const w = 2 * Math.PI * (P.depth / 10) / sr; /* грубо, [СВЕРИТЬ] */
            a1 = (1 - Math.tan(w / 2)) / (1 + Math.tan(w / 2));
            const y = a1 * data[i] + (1 - a1) * x1; /* аллпасс первого порядка */
            out[i] = data[i] * (1 - P.mix) + (y - y1) * P.mix;
            x1 = data[i]; y1 = y;
            ph += P.rate / sr; ph %= 1;
          }
          st.x1 = x1; st.y1 = y1;
          st.ph = ph; st.a1 = a1;
          return Guards.buffer(out);
        }

        case 'gate': {
          const th = Math.pow(10, P.threshold / 20); /* дБ -> линейный порог */
          const out = new Float32Array(N);
          for (let i = 0; i < N; i++) {
            out[i] = Math.abs(data[i]) < th ? 0 : data[i];
          }
          return out;
        }

        case 'crusher': {
          const bits = Math.max(2, P.bits);
          const q = Math.pow(2, bits - 1);
          const hold = Math.max(1, Math.round(sr / Math.min(sr, P.rate)));
          const out = new Float32Array(N);
          let acc = st.acc || 0, cnt = st.cnt || hold;
          for (let i = 0; i < N; i++) {
            if (cnt >= hold) { acc = Math.round(data[i] * q) / q; cnt = 0; }
            out[i] = acc; cnt++;
          }
          st.acc = acc; st.cnt = cnt;
          return out;
        }
        }
        return data;
      },

      /* сброс состояния при ПАНИКЕ / смене пресета */
      reset() { for (const k in st) delete st[k]; }
    };
    return fx;
  }

  /* ==============================================================
     РАЗДЕЛ 5. ПРОЦЕССОР — конвейер. Главная функция wrap():
     обернуть ЛЮБОЙ источник звука защитами и эффектами.
     ============================================================== */
  const CHAIN = ['dist', 'vibrato', 'phaser', 'double', 'delay', 'reverb', 'gate', 'crusher'];
  /* порядок: дисторшн режет сырьё раньше всего, крашер — финальная
     огранка. [СВЕРИТЬ] с реальной цепочкой движка. */

  function Processor(sampleRate) {
    const sr = Guards.int(sampleRate, 8000, 192000, 48000, 'частота дискретизации');
    const effects = {};
    CHAIN.forEach(n => { effects[n] = makeEffect(n); });

    const proc = {
      sampleRate: sr,
      effects,             /* прямой доступ к эффектам (нужно пресетам) */
      wave: 'square',      /* текущая волна пульта; меняется через setWave */

      /* выбор волны кнопками пульта */
      setWave(name) {
        proc.wave = Guards.oneOf(name, ['square','square50','square25','square12.5','square6.25',
                                        'triangle','triangleBass','saw','sawBass',
                                        'sine','sineBass','circle','nwave'], 'square', 'волна');
        return proc;
      },

      /* тумблеры пульта: ВЫКЛ по умолчанию */
      set(name, patch) {
        const fx = effects[Guards.oneOf(name, CHAIN, 'delay', 'эффект')];
        if (patch === false || patch === null) { fx.on = false; return proc; }
        if (patch === true) { fx.on = true; return proc; }
        fx.set(patch); fx.on = true; return proc;
      },
      allOff() { CHAIN.forEach(n => { effects[n].on = false; effects[n].reset(); }); return proc; },
      /* ■ ВСЁ ВЫКЛ + полный сброс = PANIC */
      panic() { proc.allOff(); return proc; },

      /* прогон буфера через конвейер */
      run(data) {
        try {
          Guards.buffer(data);
          let out = data;
          for (const n of CHAIN) out = effects[n].process(out, sr);
          return Guards.buffer(out);
        } catch (e) {
          Log.push('PROC.run', e && e.message ? e.message : String(e));
          return data;
        }
      },

      /* ===== ГЛАВНАЯ ФУНКЦИЯ ФРЕЙМВОРКА =====
         wrap(anyGenerator) — обернуть любой источник звука.
         Генератор: () -> Float32Array. Результат: () -> защищённый
         Float32Array (NaN вычищены, клиппинг прижат, конвейер прошёл). */
      wrap(generator) {
        if (typeof generator !== 'function') {
          Log.push('PROC.wrap', 'источник не функция', 'возвращён генератор тишины');
          return () => new Float32Array(0);
        }
        const wrapped = (...args) => {
          let data;
          try { data = generator(...args); }
          catch (e) { Log.push('PROC.wrap', 'источник упал: ' + (e && e.message), 'выдан буфер тишины'); return new Float32Array(128); }
          if (!(data instanceof Float32Array)) {
            Log.push('PROC.wrap', 'источник отдал не Float32Array', 'выдан буфер тишины');
            return new Float32Array(128);
          }
          return proc.run(data);
        };
        wrapped.process = proc; /* доступ к конвейеру снаружи */
        return wrapped;
      }
    };
    return proc;
  }

  /* ==============================================================
     РАЗДЕЛ 6. НОТЫ И РЕЖИМЫ — как на пульте.
     ============================================================== */
  const NOTE_MIN = 24, NOTE_MAX = 78; /* из справки движка */

  /* октава 0 (12..23) — модификаторы v1.4.28:
     C0=12 Power Mute, D0=13 Chromatic (+19 полутонов, 50% громкости) */
  const Modifiers = {
    pm: false, chr: false, /* тумблеры PM/CHR пульта */
    applyTo(note) {
      if (note === 12 && Modifiers.pm)  return { mute: true };
      if (note === 13 && Modifiers.chr) return { transpose: 19, gain: 0.5 };
      return {};
    }
  };

  /* Туше: SOFT/HARD/FIXED — атака огибающей [СВЕРИТЬ] с движком */
  const Touch = {
    SOFT:  { attack: 0.010 }, /* 10 мс мягкий вход */
    HARD:  { attack: 0.001 }, /* 1 мс жёсткий вход */
    FIXED: { attack: 0.0, fixed: true } /* без огибающей */
  };

  /* Сустейн: 1/8, 1/4, 1/2 от такта при ТЕМПЕ (дефолт 120 BPM) */
  function sustainSeconds(tactFraction, bpm) {
    const b = Guards.num(bpm, 30, 300, 120, 'темп');
    const f = Guards.oneOf(tactFraction, ['1/8', '1/4', '1/2'], '1/4', 'сустейн');
    const beat = 60 / b, tact = beat * 4;
    return tact * (f === '1/8' ? 0.125 : f === '1/4' ? 0.25 : 0.5);
  }

  /* частота ноты: MIDI-номер -> Гц (A4=69=440 Гц) */
  function noteToFreq(n) { return 440 * Math.pow(2, (n - 69) / 12); }

  /* ==============================================================
     РАЗДЕЛ 7. ПРЕСЕТЫ — ЧИП-РОК, ЧИП-МЕТЛ, ЧИСТЫЙ.
     Значения стартовые — дефолты пульта; [СВЕРИТЬ] с движком.
     ============================================================== */
  const Presets = {
    'ЧИП-РОК': {
      wave: 'square', touch: 'HARD',
      dist:    { on: true, grain: 40, mix: 0.5, volume: 0.6 },
      delay:   { on: true, time: 250, feedback: 0.3, mix: 0.2 }
    },
    'ЧИП-МЕТЛ': {
      wave: 'square6.25', touch: 'HARD',
      dist:    { on: true, grain: 100, mix: 0.9, volume: 0.8 },
      crusher: { on: true, bits: 6, rate: 32000 },
      delay:   { on: true, time: 120, feedback: 0.45, mix: 0.25 }
    },
    'ЧИСТЫЙ': {
      wave: 'sine', touch: 'SOFT' /* всё выключено */
    },
    load(proc, name) {
      const p = Presets[Guards.oneOf(name, ['ЧИП-РОК', 'ЧИП-МЕТЛ', 'ЧИСТЫЙ'], 'ЧИСТЫЙ', 'пресет')];
      proc.allOff();
      for (const k of CHAIN) if (p[k]) proc.set(k, p[k]);
      return proc;
    },
    /* пользовательский пресет: JSON туда-обратно с гардами на входе */
    save(proc, name) {
      const state = {
        _meta: { dwk: DWK.VERSION, saved: new Date().toISOString(), name: String(name || 'без имени') },
        sampleRate: proc.sampleRate
      };
      for (const k of DWK.CHAIN) {
        const fx = proc.effects ? proc.effects[k] : null;
        if (fx && fx.on) state[k] = { on: true, params: fx.params };
      }
      return JSON.stringify(state, null, 2);
    },
    fromJSON(proc, jsonText) {
      let parsed;
      try { parsed = JSON.parse(jsonText); }
      catch (e) { Log.push('PRESET', 'битый JSON: ' + e.message, 'пресет не применён'); return proc; }
      for (const k of DWK.CHAIN) {
        if (parsed[k]) proc.set(k, parsed[k].params || parsed[k]);
      }
      return proc;
    }
  };

  /* ==============================================================
     РАЗДЕЛ 8. САМОПРОВЕРКА — как ТЕСТОВЫЙ СТЕНД движка.
     Синус C4 -> конвейер -> буфер без NaN и клиппинга за 1.0.
     ============================================================== */
  function selfTest() {
    let ok = true;
    try {
      const proc = Processor(48000);
      const tone = Waves.fill('sine', noteToFreq(60), 4800, 48000); /* C4, 0.1 c */
      proc.set('delay',  { time: 250, feedback: 0.3, mix: 0.3 });
      proc.set('crusher',{ bits: 8, rate: 48000 });
      const out = proc.run(tone.data);
      for (let i = 0; i < out.length; i++) {
        if (!isFinite(out[i]) || Math.abs(out[i]) > 1.0001) { ok = false; break; }
      }
      /* крашер 8 бит обязан квантовать: max |y| лежит на сетке 2^-7 */
      proc.allOff();
      proc.set('crusher', { bits: 8, rate: 48000 });
      const q = proc.run(new Float32Array([0.37, -0.9, 0.123]));
      for (let i = 0; i < q.length; i++) {
        if (Math.abs(q[i] * 128 - Math.round(q[i] * 128)) > 1e-6) { ok = false; break; }
      }
      /* гард ноты: 20 и 90 -> null */
      if (Guards.note(20) !== null || Guards.note(90) !== null || Guards.note(60) !== 60) ok = false;
      Log.push('SELFTEST', ok ? 'все проверки пройдены' : 'есть провалы — см. журнал', ok ? 'OK' : 'нужна ревизия');
      return ok;
    } catch (e) {
      Log.push('SELFTEST', String(e), 'каркас повреждён');
      return false;
    }
  }

  return {
    VERSION: '0.1-dwk-fw',
    NOTE_MIN, NOTE_MAX,
    Log, Guards, Waves, Processor, Modifiers, Touch, Presets,
    sustainSeconds, noteToFreq, selfTest,
    CHAIN
  };
})();

/* экспорт для браузера и для ворклета/Node */
if (typeof globalThis !== 'undefined') globalThis.DWK = DWK;
if (typeof module !== 'undefined' && module.exports) module.exports = DWK;
